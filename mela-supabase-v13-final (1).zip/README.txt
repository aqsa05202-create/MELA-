Mela v13 (sabse naya, poora version): profile photo (tap karke badlein), cover poster, filters, stories,
Inbox, notifications, TikTok-style Reels/profile/upload, Google login.
Sirf index.html upload karein (GitHub ya Netlify).
